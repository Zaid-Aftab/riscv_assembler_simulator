from instructiondict import *
from reg_dicts import *
from mem_loc import *

def twos_comp(s):
    inverted = ''.join('0' if bit == '1' else '1' for bit in s)  # Flip bits
    carry = 1
    result = ''
    
    for bit in inverted[::-1]:  # Add 1 from LSB
        if bit == '1' and carry == 1:
            result = '0' + result
        elif bit == '0' and carry == 1:
            result = '1' + result
            carry = 0
        else:
            result = bit + result

    return result
class Instr:
    def __init__(self, ins, pc):
        self.instr = ins
        self.opcode = ins[-7:]
        self.pc = pc

    def parse(self, i, y):
        x = [i[y[j]:y[j+1]] for j in range(len(y)-1)]
        j = [i[:y[0]]]
        j.extend(x)
        return j

    def twoscomp(self, val, length):
        if val >= 0:
            return format(val, f'0{length}b')
        else:
            return format((1 << length) + val, f'0{length}b')



class R_type(Instr):
    def __init__(self, ins, pc):
        super().__init__(ins, pc)
        self.instr = self.parse(self.instr,[7,12,17,20,25,32])
        self.rs2 = self.instr[1]
        self.rs1 = self.instr[2]
        self.rd = self.instr[4]
        self.comp = [self.instr[0],self.instr[3],self.opcode]
    
    def execute(self):
        print("r type")
        if self.comp == Rtype['add']:
            print('add')
            print('rs1 = ', self.rs1)
            print('rs2 = ',self.rs2)
            print('rd = ',self.rd)
            reg_vals[self.rd] = reg_vals[self.rs1] + reg_vals[self.rs2]
        elif self.comp == Rtype['sub']:
            print('sub')
            print('rs1 = ', self.rs1)
            print('rs2 = ',self.rs2)
            print('rd = ',self.rd)
            reg_vals[self.rd] = reg_vals[self.rs1] - reg_vals[self.rs2]
        elif self.comp == Rtype['slt']:
            print('slt')
            print('rs1 = ', self.rs1)
            print('rs2 = ', self.rs2)
            reg_vals[self.rd] = 1 if reg_vals[self.rs1] < reg_vals[self.rs2] else 0
        elif self.comp == Rtype['or']:
            print('or')
            reg_vals[self.rd] = reg_vals[self.rs1] | reg_vals[self.rs2]
        elif self.comp == Rtype['and']:
            print('and')
            reg_vals[self.rd] = reg_vals[self.rs1] & reg_vals[self.rs2]
        elif self.comp == Rtype['srl']:
            print('srl')
            print('rs1 = ', reg_vals[self.rs1])
            unsignedrs1 = 2**32 + reg_vals[self.rs1] if reg_vals[self.rs1] <0 else reg_vals[self.rs1]
            print(int('{:032b}'.format(reg_vals[self.rs2])[-5:],2) )
            reg_vals[self.rd] = unsignedrs1 >> int('{:032b}'.format(reg_vals[self.rs2])[-5:],2) 
        self.pc += 4

class I_type(Instr):
    def __init__(self, ins, pc):
        super().__init__(ins, pc)
        self.instr = self.parse(self.instr, [12, 17, 20, 25, 32])
        self.imm = str(self.instr[0])  
        self.rs1 = self.instr[1]
        self.rd = self.instr[3]
        self.comp = [self.opcode, self.instr[2]]

    def execute(self):
        print("i type")
        if self.comp == Itype['lw']:
            print('lw')
            if self.imm[0] == '0':
                print(int(self.imm, 2),reg_vals[self.rs1])
                if int(self.imm, 2) + reg_vals[self.rs1] in mem:
                    reg_vals[self.rd] = mem[int(self.imm, 2) + reg_vals[self.rs1]]
                else:
                    reg_vals[self.rd] = 7
            else:
                reg_vals[self.rd] = mem[-int(twos_comp(self.imm),2) + reg_vals[self.rs1]]
            self.pc += 4

        elif self.comp == Itype['addi']:
            print('addi')
            print('rd = ', self.rd)
            sextimm = int(self.imm, 2) if str(self.imm)[0] == '0' else -int(self.twoscomp(int(self.imm, 2), 12), 2)
            print('imm = ', sextimm)
            if self.imm[0] == '0':
                reg_vals[self.rd] = int(self.imm, 2) + reg_vals[self.rs1]
            else:
                reg_vals[self.rd] = -int(self.twoscomp(int(self.imm, 2), 12), 2) + reg_vals[self.rs1]
            self.pc += 4

        elif self.comp == Itype['jalr']:
            print('jalr')
            print('rd =', self.rd)
            if self.rd!='00000':
                reg_vals[self.rd] = self.pc + 4 
            self.sextimm = int(self.imm, 2) if self.imm[0] == '0' else -int(twos_comp(self.imm), 2)
            self.pc = (reg_vals[self.rs1] + self.sextimm) & ~1


class B_type(Instr):
    def __init__(self, ins, pc):
        super().__init__(ins, pc)
        ins=ins[::-1]
        self.imm=str(ins[8:12]+ins[25:31]+ins[7]+ins[31])
        self.imm=self.imm[::-1]
        self.imm=self.imm+'0'
        self.rs1=ins[15:20][::-1]
        self.rs2=ins[20:25][::-1]
        self.comp=[self.opcode,ins[12:15][::-1]]
        self.sextimm=int(self.imm,2) if str(self.imm)[0]=='0' else -int(twos_comp(self.imm),2)
        print(self.imm)
        print(self.sextimm)
    
    def execute(self):
        print("b type")
        if self.comp==Btype['beq']:
            print('beq')
            if(reg_vals[self.rs1]==reg_vals[self.rs2]):
                self.pc+=self.sextimm
            else:
                self.pc+=4
        elif self.comp==Btype['bne']:
            print('bne')
            if(reg_vals[self.rs1]!=reg_vals[self.rs2]):
                self.pc+=self.sextimm
            else:
                self.pc+=4

class J_type(Instr):
    def __init__(self, ins, pc):
        super().__init__(ins, pc)
        ins=ins[::-1]
        self.imm=str(ins[21:31]+ins[20]+ins[12:20]+ins[31])
        self.imm=self.imm[::-1]
        self.imm=self.imm+'0'
        self.rd=ins[7:12][::-1]
        self.comp=[self.opcode]
        self.sextimm=int(self.imm,2) if str(self.imm)[0]=='0' else -int(twos_comp(self.imm),2)

    def execute(self):
        print("j type")
        if self.comp==Jtype['jal']:
            print('jal')
            reg_vals[self.rd] = self.pc + 4
            self.pc += self.sextimm

class S_type(Instr):
    def __init__(self, ins, pc):
        super().__init__(ins, pc)
        ins=ins[::-1]
        self.imm=str(ins[7:12]+ins[25:])
        self.imm=self.imm[::-1]
        self.rs1=ins[15:20][::-1]
        self.rs2=ins[20:25][::-1]
        self.comp=[self.opcode,ins[12:15][::-1]]
        self.sextimm=int(self.imm,2) if str(self.imm)[0]=='0' else -int(twos_comp(self.imm),2)
    
    def execute(self):
        print("s type")
        if self.comp==Stype['sw']:
            print('sw')
            n=reg_vals[self.rs1]+self.sextimm
            if n in mem:
                mem[reg_vals[self.rs1]+self.sextimm] = reg_vals[self.rs2]
            self.pc+=4
        
