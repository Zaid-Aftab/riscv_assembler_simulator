#format for R-type: [funct7, funct3, opcode]
Rtype = {"add": ["0000000", "000", "0110011"], "sub": ["0100000", "000", "0110011"], "slt": ["0000000", "010", "0110011"], "srl": ["0000000", "101", "0110011"], "or": ["0000000", "110", "0110011"], "and": ["0000000", "111", "0110011"]}

#format for I-type :[opcode, funct3]
Itype = {"lw": ["0000011", "010"], "addi": ["0010011", "000"], "jalr": ["1100111", "000"]}

#format for S-type :[opcode, funct3]  
Stype = {"sw": ["0100011", "010"]}

#format for J-type :[opcode]
Jtype = {"jal": ["1101111"]}

#format for B-type: [opcode, funct3]
Btype = {"beq": ["1100011", "000"], "bne": ["1100011", "001"]}
