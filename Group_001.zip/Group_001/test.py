        elif self.comp == Itype['jalr']:
            self.imm=self.imm+'0'
            print('jalr')
            print('rd = ', self.rd)
            reg_vals[self.rd] = self.pc + 4
            if str(self.imm)[0] == '0':
                self.pc = (reg_vals[self.rs1] + int(self.imm, 2))
            else:
                self.pc = (reg_vals[self.rs1] - int(self.twoscomp(int(self.imm, 2), 12), 2))
            if self.pc % 2 != 0:
                self.pc -= 1
            if self.pc < 0:
                self.pc = 2**32 + self.pc