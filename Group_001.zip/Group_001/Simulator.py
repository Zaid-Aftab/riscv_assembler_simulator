from inst import *
from reg_dicts import *
from instructiondict import *
from mem_loc import *
import sys

if len(sys.argv) < 2:
    print("Usage: python script.py <file_path>")
    sys.exit(1)

ifile = sys.argv[1]
ofile = sys.argv[2]
# ifile='input.txt'
# ofile='output.txt'
class Sim:
    def __init__(self, ins, ofile, pc):
        self.ins = ins
        self.ofile = ofile
        self.pc = pc
    
    def execute(self):
        self.opcode=self.ins[-7:]
        l=[list(Rtype.values())[i][2] for i in range(len(Rtype))]
        obj=None
        # print([list(Itype.values())[i][0] for i in range(len(Itype))])
        if self.opcode in l:
            obj=R_type(self.ins, self.pc)
        elif self.opcode in [list(Itype.values())[i][0] for i in range(len(Itype))]:
            obj=I_type(self.ins, self.pc)
        elif self.opcode == list(Jtype.values())[0][0]:
            obj=J_type(self.ins, self.pc)
        elif self.opcode == list(Stype.values())[0][0]:
            obj=S_type(self.ins, self.pc)
        elif self.opcode in [list(Btype.values())[i][0] for i in range(len(Btype))]:
            obj=B_type(self.ins, self.pc)
        
        obj.execute()
        #print(obj.pc)
        self.pc = obj.pc
    
    def write_line(self):
        w='0b' + format(self.pc,'032b') + ' '
        for i in reg_vals:
            value=reg_vals[i]
            if value>=0:
                w=w+'0b' + format(value,'032b') + ' '
            else:
                value = 2**32 + value
                w=w+'0b' + format(value,'032b') + ' '
        w=w+'\n'
        o.write(w)

    def write_mem(self):
        with open(self.ofile,'a') as f:
            for i in mem:
                w= '0x' + format(i,'08X') + ':'
                value=mem[i]
                if value>=0:
                    w+='0b' + format(mem[i],'032b') + '\n'
                else:
                    value = 2**32 + value
                    w+='0b' + format(value,'032b') + '\n'
                f.write(w)

o=open(ofile,"w")
with open(ifile,'r') as f:
    lines=f.readlines()
    pc=0
    while True:
        print(pc)
        i=lines[pc//4]
        i=i.strip()
        if i == '00000000000000000000000001100011':
            wow.write_line()
            break
        wow= Sim(i, ofile, pc)
        wow.execute()
        wow.write_line()
        pc=wow.pc
    o.close()
    wow.write_mem()





